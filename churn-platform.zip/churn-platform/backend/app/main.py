from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.utils.pipeline import load_artifacts
from app.routes import predict, customers, analytics

app = FastAPI(
    title="Customer Churn Prediction API",
    description="Predicts customer churn risk using a tuned XGBoost model.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(predict.router, tags=["Prediction"])
app.include_router(customers.router, tags=["Customers"])
app.include_router(analytics.router, tags=["Analytics"])


@app.on_event("startup")
def on_startup():
    init_db()
    load_artifacts()


@app.get("/")
def root():
    return {"message": "Customer Churn Prediction API is running"}


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": True}
