from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.schemas import CustomerRecord
from app.database import get_db, CustomerRecordORM

router = APIRouter()


@router.get("/customers", response_model=List[CustomerRecord])
def list_customers(db: Session = Depends(get_db)):
    records = db.query(CustomerRecordORM).order_by(CustomerRecordORM.id.desc()).all()
    return [
        CustomerRecord(
            id=r.id,
            gender=r.gender,
            tenure=r.tenure,
            contract=r.contract,
            monthly_charges=r.monthly_charges,
            churn_probability=round(r.churn_probability, 4),
            prediction=r.prediction,
            risk_level=r.risk_level,
        )
        for r in records
    ]


@router.get("/customers/{customer_id}", response_model=CustomerRecord)
def get_customer(customer_id: int, db: Session = Depends(get_db)):
    record = db.query(CustomerRecordORM).filter(CustomerRecordORM.id == customer_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Customer not found")
    return CustomerRecord(
        id=record.id,
        gender=record.gender,
        tenure=record.tenure,
        contract=record.contract,
        monthly_charges=record.monthly_charges,
        churn_probability=round(record.churn_probability, 4),
        prediction=record.prediction,
        risk_level=record.risk_level,
    )
