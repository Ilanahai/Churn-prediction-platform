from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.schemas import AnalyticsResponse
from app.database import get_db, CustomerRecordORM

router = APIRouter()


@router.get("/analytics", response_model=AnalyticsResponse)
def get_analytics(db: Session = Depends(get_db)):
    total = db.query(func.count(CustomerRecordORM.id)).scalar() or 0
    healthy = db.query(func.count(CustomerRecordORM.id)).filter(
        CustomerRecordORM.risk_level == "LOW"
    ).scalar() or 0
    at_risk = db.query(func.count(CustomerRecordORM.id)).filter(
        CustomerRecordORM.risk_level == "MEDIUM"
    ).scalar() or 0
    critical = db.query(func.count(CustomerRecordORM.id)).filter(
        CustomerRecordORM.risk_level == "HIGH"
    ).scalar() or 0
    avg_proba = db.query(func.avg(CustomerRecordORM.churn_probability)).scalar() or 0.0

    return AnalyticsResponse(
        total_customers=total,
        healthy=healthy,
        at_risk=at_risk,
        critical=critical,
        average_churn_probability=round(float(avg_proba), 4),
    )
