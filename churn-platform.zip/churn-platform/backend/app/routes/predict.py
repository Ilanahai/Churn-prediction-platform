from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.schemas import CustomerInput, PredictionResponse
from app.utils.pipeline import predict_one
from app.utils.cache import get_cached_prediction, set_cached_prediction
from app.database import get_db, CustomerRecordORM

router = APIRouter()


@router.post("/predict", response_model=PredictionResponse)
def predict_churn(customer: CustomerInput, db: Session = Depends(get_db)):
    customer_dict = customer.model_dump()

    cached = get_cached_prediction(customer_dict)
    if cached:
        proba, prediction, risk_level = (
            cached["churn_probability"],
            cached["prediction"],
            cached["risk_level"],
        )
    else:
        proba, prediction, risk_level = predict_one(customer_dict)
        set_cached_prediction(
            customer_dict,
            {
                "churn_probability": proba,
                "prediction": prediction,
                "risk_level": risk_level,
            },
        )

    record = CustomerRecordORM(
        gender=customer.gender,
        tenure=customer.tenure,
        contract=customer.Contract,
        monthly_charges=customer.MonthlyCharges,
        churn_probability=proba,
        prediction=prediction,
        risk_level=risk_level,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    return PredictionResponse(
        customer_id=str(record.id),
        churn_probability=round(proba, 4),
        prediction=prediction,
        risk_level=risk_level,
    )
