import os
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://churn_user:churn_pass@localhost:5432/churn_db",
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class CustomerRecordORM(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    gender = Column(String)
    tenure = Column(Integer)
    contract = Column(String)
    monthly_charges = Column(Float)
    churn_probability = Column(Float)
    prediction = Column(String)
    risk_level = Column(String)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
