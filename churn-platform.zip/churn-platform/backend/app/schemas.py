from pydantic import BaseModel, Field
from typing import Optional


class CustomerInput(BaseModel):
    """Raw customer features, matching the Telco churn dataset schema."""

    gender: str = Field(..., examples=["Male"])
    SeniorCitizen: int = Field(..., ge=0, le=1)
    Partner: str = Field(..., examples=["Yes"])
    Dependents: str = Field(..., examples=["No"])
    tenure: int = Field(..., ge=0, examples=[12])
    PhoneService: str = Field(..., examples=["Yes"])
    MultipleLines: str = Field(..., examples=["No"])
    InternetService: str = Field(..., examples=["Fiber optic"])
    OnlineSecurity: str = Field(..., examples=["No"])
    OnlineBackup: str = Field(..., examples=["Yes"])
    DeviceProtection: str = Field(..., examples=["No"])
    TechSupport: str = Field(..., examples=["No"])
    StreamingTV: str = Field(..., examples=["Yes"])
    StreamingMovies: str = Field(..., examples=["No"])
    Contract: str = Field(..., examples=["Month-to-month"])
    PaperlessBilling: str = Field(..., examples=["Yes"])
    PaymentMethod: str = Field(..., examples=["Electronic check"])
    MonthlyCharges: float = Field(..., ge=0, examples=[70.35])
    TotalCharges: float = Field(..., ge=0, examples=[845.5])


class PredictionResponse(BaseModel):
    customer_id: Optional[str] = None
    churn_probability: float
    prediction: str          # "Churn" | "No Churn"
    risk_level: str          # "LOW" | "MEDIUM" | "HIGH"


class CustomerRecord(BaseModel):
    id: int
    gender: str
    tenure: int
    contract: str
    monthly_charges: float
    churn_probability: float
    prediction: str
    risk_level: str


class AnalyticsResponse(BaseModel):
    total_customers: int
    healthy: int
    at_risk: int
    critical: int
    average_churn_probability: float
