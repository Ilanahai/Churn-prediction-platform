"""
Shared preprocessing pipeline for the churn model.

Mirrors the exact encoding used in ml/notebooks/Churn_Prediction_XGBoost.ipynb
so that predictions at inference time match what the model was trained on.
"""

import pandas as pd
import joblib
from pathlib import Path

MODELS_DIR = Path(__file__).resolve().parent.parent / "models"

_model = None
_scaler = None
_threshold = None
_feature_columns = None


def load_artifacts():
    """Load model, scaler, threshold and feature column order once at startup."""
    global _model, _scaler, _threshold, _feature_columns
    _model = joblib.load(MODELS_DIR / "churn_xgb_model.pkl")
    _scaler = joblib.load(MODELS_DIR / "churn_scaler.pkl")
    _threshold = joblib.load(MODELS_DIR / "churn_threshold.pkl")
    _feature_columns = joblib.load(MODELS_DIR / "churn_feature_columns.pkl")
    return _model, _scaler, _threshold, _feature_columns


def get_artifacts():
    if _model is None:
        return load_artifacts()
    return _model, _scaler, _threshold, _feature_columns


BINARY_COLS = ["Partner", "Dependents", "PhoneService", "PaperlessBilling"]
MULTI_CAT_COLS = [
    "MultipleLines", "InternetService", "OnlineSecurity", "OnlineBackup",
    "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
    "Contract", "PaymentMethod",
]


def preprocess(customer: dict) -> pd.DataFrame:
    """Apply the same cleaning/encoding steps used in training to a single record."""
    df = pd.DataFrame([customer])

    df["gender"] = df["gender"].map({"Male": 1, "Female": 0})
    for col in BINARY_COLS:
        df[col] = df[col].map({"Yes": 1, "No": 0})

    df = pd.get_dummies(df, columns=MULTI_CAT_COLS, drop_first=True)

    df["avg_monthly_spend"] = df["TotalCharges"] / df["tenure"].replace(0, 1)
    df["tenure_years"] = df["tenure"] / 12

    _, _, _, feature_columns = get_artifacts()

    # Align columns to training-time feature order; missing one-hot columns
    # (categories not hit by this single record) are filled with 0.
    df = df.reindex(columns=feature_columns, fill_value=0)
    return df


def predict_one(customer: dict):
    model, scaler, threshold, _ = get_artifacts()
    X = preprocess(customer)
    X_scaled = scaler.transform(X)
    proba = float(model.predict_proba(X_scaled)[:, 1][0])
    prediction = "Churn" if proba >= threshold else "No Churn"

    if proba >= 0.7:
        risk_level = "HIGH"
    elif proba >= 0.4:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    return proba, prediction, risk_level
