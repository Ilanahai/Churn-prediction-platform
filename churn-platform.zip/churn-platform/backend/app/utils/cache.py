import os
import json
import hashlib
import redis

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
CACHE_TTL_SECONDS = 60 * 10  # 10 minutes

_client = None


def get_client():
    global _client
    if _client is None:
        _client = redis.from_url(REDIS_URL, decode_responses=True)
    return _client


def make_key(customer: dict) -> str:
    payload = json.dumps(customer, sort_keys=True)
    digest = hashlib.sha256(payload.encode()).hexdigest()
    return f"prediction:{digest}"


def get_cached_prediction(customer: dict):
    try:
        client = get_client()
        cached = client.get(make_key(customer))
        return json.loads(cached) if cached else None
    except redis.exceptions.RedisError:
        # Cache is a nice-to-have, never block predictions if Redis is down
        return None


def set_cached_prediction(customer: dict, result: dict):
    try:
        client = get_client()
        client.setex(make_key(customer), CACHE_TTL_SECONDS, json.dumps(result))
    except redis.exceptions.RedisError:
        pass
