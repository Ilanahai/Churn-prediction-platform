module churn-batch-service

go 1.22
