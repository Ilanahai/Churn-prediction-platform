// Batch Prediction Service (Go)
//
// Accepts a CSV of customers at POST /batch-predict, calls the FastAPI
// /predict endpoint for each row concurrently, and returns aggregated
// results. Demonstrates a polyglot backend: Go handles high-throughput
// batch I/O while Python/FastAPI owns the ML inference path.
package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"sync"
)

var predictAPIURL = getEnv("PREDICT_API_URL", "http://backend:8000/predict")

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

type PredictionResult struct {
	Row        int     `json:"row"`
	Prediction string  `json:"prediction,omitempty"`
	Probability float64 `json:"churn_probability,omitempty"`
	Error      string  `json:"error,omitempty"`
}

func callPredictAPI(record map[string]string) (*PredictionResult, error) {
	body, err := json.Marshal(record)
	if err != nil {
		return nil, err
	}

	resp, err := http.Post(predictAPIURL, "application/json", bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)

	var parsed struct {
		ChurnProbability float64 `json:"churn_probability"`
		Prediction       string  `json:"prediction"`
	}
	if err := json.Unmarshal(respBody, &parsed); err != nil {
		return nil, fmt.Errorf("bad response: %s", string(respBody))
	}

	return &PredictionResult{
		Prediction:  parsed.Prediction,
		Probability: parsed.ChurnProbability,
	}, nil
}

func batchPredictHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	reader := csv.NewReader(r.Body)
	headers, err := reader.Read()
	if err != nil {
		http.Error(w, "failed to read CSV header", http.StatusBadRequest)
		return
	}

	var wg sync.WaitGroup
	var mu sync.Mutex
	results := []PredictionResult{}
	rowNum := 0

	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			continue
		}
		rowNum++

		record := map[string]string{}
		for i, h := range headers {
			if i < len(row) {
				record[h] = row[i]
			}
		}

		wg.Add(1)
		go func(n int, rec map[string]string) {
			defer wg.Done()
			result, err := callPredictAPI(rec)
			mu.Lock()
			defer mu.Unlock()
			if err != nil {
				results = append(results, PredictionResult{Row: n, Error: err.Error()})
				return
			}
			result.Row = n
			results = append(results, *result)
		}(rowNum, record)
	}

	wg.Wait()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"total_rows": rowNum,
		"results":    results,
	})
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte(`{"status":"ok"}`))
}

func main() {
	http.HandleFunc("/batch-predict", batchPredictHandler)
	http.HandleFunc("/health", healthHandler)

	port := getEnv("PORT", "8080")
	log.Printf("Batch prediction service listening on :%s", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
