# Customer Churn Prediction Platform

An end-to-end machine learning system that predicts telecom customer churn — combining a tuned XGBoost model, a FastAPI backend, a Go batch-prediction microservice, and a real-time React dashboard.

## Overview

Telecom providers lose revenue when customers quietly churn. This project predicts the probability that a given customer will churn, based on their account, contract, and service usage data, so retention teams can act before it happens.

| Layer | What it does |
|---|---|
| 🧠 ML Pipeline | Cleans data, engineers features, trains & tunes XGBoost |
| ⚙️ FastAPI Backend | Serves predictions, stores results in PostgreSQL, caches with Redis |
| 🐹 Go Batch Service | Accepts CSV uploads, calls `/predict` concurrently for bulk scoring |
| 🎨 React Dashboard | Visualizes churn risk, KPIs, and lets users run live predictions |

## Architecture

```
React Dashboard ──► FastAPI (/predict, /customers, /analytics) ──► PostgreSQL
                                    │                    └──► Redis (cache)
Go Batch Service ───────────────────┘
        ▲
   CSV upload
```

## Project Structure

```
churn-platform/
├── ml/
│   ├── notebooks/Churn_Prediction_XGBoost.ipynb   # EDA → training → tuning
│   ├── data/{raw,processed}/
│   └── models/                                     # saved .pkl artifacts
├── backend/                                        # FastAPI app
│   └── app/{routes,utils,models}/
├── batch-service/                                  # Go microservice
├── frontend/                                        # React (Vite) dashboard
├── k8s/                                            # Kubernetes manifests
├── docker-compose.yml
└── README.md
```

## Getting Started

### 1. Train the model
```bash
cd ml/notebooks
jupyter notebook Churn_Prediction_XGBoost.ipynb
```
Run all cells. This saves `churn_xgb_model.pkl`, `churn_scaler.pkl`, `churn_threshold.pkl`, and `churn_feature_columns.pkl` into `ml/models/`.

### 2. Run everything with Docker Compose
```bash
cp -r ml/models/* backend/app/models/
docker compose up --build
```
- Backend: http://127.0.0.1:8000/docs
- Dashboard: http://127.0.0.1:5173
- Batch service: http://127.0.0.1:8080/health

### 3. (Optional) Run on Kubernetes locally
```bash
minikube start
eval $(minikube docker-env)
docker build -t churn-backend:latest ./backend
docker build -t churn-frontend:latest ./frontend
docker build -t churn-batch-service:latest ./batch-service
kubectl apply -f k8s/
minikube service frontend
```

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | API + model health check |
| POST | `/predict` | Predict churn for one customer |
| GET | `/customers` | List all scored customers |
| GET | `/customers/{id}` | Get one customer's details |
| GET | `/analytics` | Aggregated risk counts |
| POST | `/batch-predict` (Go service) | Score a CSV of customers |

## Model Performance

Final model: tuned XGBoost with F1-optimized threshold, evaluated on a held-out test set.

| Model | F1 | ROC-AUC |
|---|---|---|
| Logistic Regression | see notebook output | — |
| Random Forest | see notebook output | — |
| XGBoost (tuned) | see notebook output | — |

*(Fill in your actual numbers after running the notebook.)*

## Key Engineering Decisions
- **No data leakage:** `customerID` dropped; `TotalCharges` blanks (all `tenure == 0`) filled with 0 rather than dropped.
- **Threshold tuning over default 0.5:** maximized F1 on the validation set.
- **Shared preprocessing:** `backend/app/utils/pipeline.py` mirrors the notebook's encoding exactly, so inference matches training.
- **Cache-aside pattern:** Redis caches repeated predictions; falls back gracefully if Redis is down.
- **Polyglot backend:** Go handles high-throughput batch CSV scoring while Python/FastAPI owns ML inference — demonstrates working across languages on one system.

## 📚 Sources & Acknowledgements

### Dataset
- **IBM Telco Customer Churn Dataset** — Mendeley Data, DOI: [10.17632/phsxg9ssrf.1](https://data.mendeley.com/datasets/phsxg9ssrf). 7,043 real customer records from a telecommunications provider, covering demographics, account details, subscribed services, and churn status.

### ML / Data Libraries
- [scikit-learn](https://scikit-learn.org/) — preprocessing, pipelines, baseline models
- [XGBoost](https://xgboost.readthedocs.io/) — Chen & Guestrin (2016), *"XGBoost: A Scalable Tree Boosting System"*
- [Pandas](https://pandas.pydata.org/) / [NumPy](https://numpy.org/) — data manipulation
- [Matplotlib](https://matplotlib.org/) / [Seaborn](https://seaborn.pydata.org/) — EDA visualizations

### Backend
- [FastAPI](https://fastapi.tiangolo.com/) — REST API framework
- [SQLAlchemy](https://www.sqlalchemy.org/) + [PostgreSQL](https://www.postgresql.org/) — persistence
- [Redis](https://redis.io/) — prediction caching
- [Go](https://go.dev/) — batch-prediction microservice

### Frontend
- [React](https://react.dev/) (Vite) — dashboard UI
- [Recharts](https://recharts.org/) — risk-distribution charts
- [Axios](https://axios-http.com/) — API client

### Infrastructure
- [Docker](https://www.docker.com/) — containerization
- [Kubernetes](https://kubernetes.io/) — orchestration (manifests in `k8s/`)

### Reference Inspiration
Project structure and README format inspired by an open-source predictive-maintenance ML platform (XGBoost + FastAPI + React), used as an architectural template only.

## License
MIT — feel free to use, modify, and learn from this project.
