import { useEffect, useState } from "react";
import { getAnalytics, getCustomers } from "../services/api";
import KPICard from "../components/dashboard/KPICard";
import RiskChart from "../components/dashboard/RiskChart";
import CustomerTable from "../components/customers/CustomerTable";

export default function Dashboard() {
  const [analytics, setAnalytics] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [a, c] = await Promise.all([getAnalytics(), getCustomers()]);
    setAnalytics(a);
    setCustomers(c);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  if (loading) return <p>Loading dashboard…</p>;

  return (
    <div className="page">
      <h1>Churn Risk Dashboard</h1>

      <div className="kpi-row">
        <KPICard label="Total Customers" value={analytics.total_customers} />
        <KPICard label="Healthy" value={analytics.healthy} tone="healthy" />
        <KPICard label="At Risk" value={analytics.at_risk} tone="warning" />
        <KPICard label="Critical" value={analytics.critical} tone="critical" />
      </div>

      <RiskChart analytics={analytics} />

      <h2>All Customers</h2>
      <CustomerTable customers={customers} />
    </div>
  );
}
