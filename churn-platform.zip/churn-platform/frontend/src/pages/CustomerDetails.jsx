import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getCustomer } from "../services/api";

export default function CustomerDetails() {
  const { id } = useParams();
  const [customer, setCustomer] = useState(null);

  useEffect(() => {
    getCustomer(id).then(setCustomer);
  }, [id]);

  if (!customer) return <p>Loading…</p>;

  return (
    <div className="page">
      <Link to="/">&larr; Back to dashboard</Link>
      <h1>Customer #{customer.id}</h1>
      <ul className="detail-list">
        <li><strong>Gender:</strong> {customer.gender}</li>
        <li><strong>Tenure:</strong> {customer.tenure} months</li>
        <li><strong>Contract:</strong> {customer.contract}</li>
        <li><strong>Monthly Charges:</strong> ${customer.monthly_charges.toFixed(2)}</li>
        <li><strong>Churn Probability:</strong> {(customer.churn_probability * 100).toFixed(1)}%</li>
        <li><strong>Risk Level:</strong> {customer.risk_level}</li>
      </ul>
    </div>
  );
}
