import { useState } from "react";
import { predictChurn } from "../services/api";

const initialState = {
  gender: "Male",
  SeniorCitizen: 0,
  Partner: "No",
  Dependents: "No",
  tenure: 12,
  PhoneService: "Yes",
  MultipleLines: "No",
  InternetService: "Fiber optic",
  OnlineSecurity: "No",
  OnlineBackup: "No",
  DeviceProtection: "No",
  TechSupport: "No",
  StreamingTV: "No",
  StreamingMovies: "No",
  Contract: "Month-to-month",
  PaperlessBilling: "Yes",
  PaymentMethod: "Electronic check",
  MonthlyCharges: 70.35,
  TotalCharges: 845.5,
};

const yesNo = ["Yes", "No"];

export default function Predict() {
  const [form, setForm] = useState(initialState);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await predictChurn(form);
      setResult(res);
    } catch (err) {
      setError("Prediction failed — check the API is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <h1>Predict Customer Churn</h1>

      <form className="predict-form" onSubmit={submit}>
        <label>Gender
          <select value={form.gender} onChange={(e) => update("gender", e.target.value)}>
            <option>Male</option><option>Female</option>
          </select>
        </label>

        <label>Senior Citizen
          <select value={form.SeniorCitizen} onChange={(e) => update("SeniorCitizen", Number(e.target.value))}>
            <option value={0}>No</option><option value={1}>Yes</option>
          </select>
        </label>

        <label>Partner
          <select value={form.Partner} onChange={(e) => update("Partner", e.target.value)}>
            {yesNo.map((v) => <option key={v}>{v}</option>)}
          </select>
        </label>

        <label>Dependents
          <select value={form.Dependents} onChange={(e) => update("Dependents", e.target.value)}>
            {yesNo.map((v) => <option key={v}>{v}</option>)}
          </select>
        </label>

        <label>Tenure (months)
          <input type="number" min="0" value={form.tenure}
            onChange={(e) => update("tenure", Number(e.target.value))} />
        </label>

        <label>Contract
          <select value={form.Contract} onChange={(e) => update("Contract", e.target.value)}>
            <option>Month-to-month</option><option>One year</option><option>Two year</option>
          </select>
        </label>

        <label>Internet Service
          <select value={form.InternetService} onChange={(e) => update("InternetService", e.target.value)}>
            <option>DSL</option><option>Fiber optic</option><option>No</option>
          </select>
        </label>

        <label>Payment Method
          <select value={form.PaymentMethod} onChange={(e) => update("PaymentMethod", e.target.value)}>
            <option>Electronic check</option><option>Mailed check</option>
            <option>Bank transfer</option><option>Credit card</option>
          </select>
        </label>

        <label>Monthly Charges ($)
          <input type="number" step="0.01" value={form.MonthlyCharges}
            onChange={(e) => update("MonthlyCharges", Number(e.target.value))} />
        </label>

        <label>Total Charges ($)
          <input type="number" step="0.01" value={form.TotalCharges}
            onChange={(e) => update("TotalCharges", Number(e.target.value))} />
        </label>

        <button type="submit" disabled={loading}>
          {loading ? "Predicting…" : "Predict Churn"}
        </button>
      </form>

      {error && <p className="error-text">{error}</p>}

      {result && (
        <div className={`result-card result-${result.risk_level.toLowerCase()}`}>
          <h2>{result.prediction}</h2>
          <p>Churn probability: {(result.churn_probability * 100).toFixed(1)}%</p>
          <p>Risk level: {result.risk_level}</p>
        </div>
      )}
    </div>
  );
}
