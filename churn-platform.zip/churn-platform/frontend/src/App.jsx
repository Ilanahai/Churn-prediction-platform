import { Routes, Route } from "react-router-dom";
import Navbar from "./components/common/Navbar";
import Dashboard from "./pages/Dashboard";
import Predict from "./pages/Predict";
import CustomerDetails from "./pages/CustomerDetails";

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/predict" element={<Predict />} />
          <Route path="/customers/:id" element={<CustomerDetails />} />
        </Routes>
      </main>
    </>
  );
}
