export default function KPICard({ label, value, tone = "default" }) {
  return (
    <div className={`kpi-card kpi-${tone}`}>
      <div className="kpi-value">{value}</div>
      <div className="kpi-label">{label}</div>
    </div>
  );
}
