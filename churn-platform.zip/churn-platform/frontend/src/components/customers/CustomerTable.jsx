import { Link } from "react-router-dom";

const riskClass = { LOW: "risk-low", MEDIUM: "risk-medium", HIGH: "risk-high" };

export default function CustomerTable({ customers }) {
  if (!customers?.length) {
    return <p className="empty-state">No predictions yet — try the Predict page.</p>;
  }

  return (
    <table className="customer-table">
      <thead>
        <tr>
          <th>ID</th><th>Gender</th><th>Tenure</th><th>Contract</th>
          <th>Monthly Charges</th><th>Churn Prob.</th><th>Risk</th><th></th>
        </tr>
      </thead>
      <tbody>
        {customers.map((c) => (
          <tr key={c.id}>
            <td>{c.id}</td>
            <td>{c.gender}</td>
            <td>{c.tenure} mo</td>
            <td>{c.contract}</td>
            <td>${c.monthly_charges.toFixed(2)}</td>
            <td>{(c.churn_probability * 100).toFixed(1)}%</td>
            <td><span className={`risk-badge ${riskClass[c.risk_level]}`}>{c.risk_level}</span></td>
            <td><Link to={`/customers/${c.id}`}>View</Link></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
