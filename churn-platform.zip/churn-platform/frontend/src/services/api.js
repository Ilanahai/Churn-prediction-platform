import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://127.0.0.1:8000",
});

export const getAnalytics = () => api.get("/analytics").then((r) => r.data);
export const getCustomers = () => api.get("/customers").then((r) => r.data);
export const getCustomer = (id) => api.get(`/customers/${id}`).then((r) => r.data);
export const predictChurn = (payload) => api.post("/predict", payload).then((r) => r.data);

export default api;
